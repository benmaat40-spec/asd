package dev.bigstacks.client;

import net.fabricmc.api.ClientModInitializer;

public class BigStacksClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
	}
}
