package dev.bigstacks.client;

import dev.bigstacks.BigStacks;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class BigStacksScreen extends Screen {
	private static final int[] PRESETS = {16, 64, 128, 256, 512, 1024};

	private final Screen parent;
	private EditBox input;

	public BigStacksScreen(Screen parent) {
		super(Component.literal("Big Stacks"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		int cx = this.width / 2;
		int y = this.height / 2 - 60;

		StringWidget title = new StringWidget(cx - 150, y, 300, 12, Component.literal("Items pro Stack (1-" + BigStacks.MAX_STACK + ")"), this.font);
		title.alignCenter();
		this.addRenderableWidget(title);

		this.input = new EditBox(this.font, cx - 50, y + 20, 100, 20, Component.literal("Stackgröße"));
		this.input.setMaxLength(4);
		this.input.setFilter(s -> s.matches("\\d*"));
		this.input.setValue(Integer.toString(BigStacks.getMaxStackSize()));
		this.addRenderableWidget(this.input);

		int bw = 48;
		int gap = 4;
		int total = PRESETS.length * bw + (PRESETS.length - 1) * gap;
		int x = cx - total / 2;
		for (int preset : PRESETS) {
			this.addRenderableWidget(Button.builder(Component.literal(Integer.toString(preset)),
					b -> this.input.setValue(Integer.toString(preset)))
				.bounds(x, y + 48, bw, 20).build());
			x += bw + gap;
		}

		this.addRenderableWidget(Button.builder(Component.literal("Speichern & Zurück"), b -> saveAndClose())
			.bounds(cx - 100, y + 80, 200, 20).build());
	}

	private void saveAndClose() {
		int value = BigStacks.getMaxStackSize();
		try {
			value = Integer.parseInt(this.input.getValue().trim());
		} catch (NumberFormatException ignored) {
		}
		BigStacks.setMaxStackSize(value);
		BigStacks.save();
		this.onClose();
	}

	@Override
	public void onClose() {
		this.minecraft.setScreen(this.parent);
	}
}
