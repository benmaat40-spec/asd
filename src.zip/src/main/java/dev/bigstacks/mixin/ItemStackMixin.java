package dev.bigstacks.mixin;

import dev.bigstacks.BigStacks;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemStack.class)
public abstract class ItemStackMixin {
	// Nur Items, die normal stapelbar sind (>1), bekommen die neue Stackgröße.
	// Werkzeuge, Rüstung etc. (max 1) bleiben unverändert.
	@Inject(method = "getMaxStackSize", at = @At("RETURN"), cancellable = true)
	private void bigstacks$maxStackSize(CallbackInfoReturnable<Integer> cir) {
		if (cir.getReturnValueI() > 1) {
			cir.setReturnValue(BigStacks.getMaxStackSize());
		}
	}
}
