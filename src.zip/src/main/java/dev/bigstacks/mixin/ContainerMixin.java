package dev.bigstacks.mixin;

import dev.bigstacks.BigStacks;
import net.minecraft.world.Container;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Container.class)
public interface ContainerMixin {
	// Vanilla begrenzt Container auf 99 - hier anheben, damit Stacks > 99 in Inventare passen.
	@Inject(method = "getMaxStackSize()I", at = @At("RETURN"), cancellable = true)
	private void bigstacks$containerLimit(CallbackInfoReturnable<Integer> cir) {
		cir.setReturnValue(Math.max(cir.getReturnValueI(), BigStacks.getMaxStackSize()));
	}
}
