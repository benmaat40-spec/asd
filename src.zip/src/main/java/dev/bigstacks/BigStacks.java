package dev.bigstacks;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class BigStacks implements ModInitializer {
	public static final String MOD_ID = "bigstacks";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	public static final int MIN_STACK = 1;
	public static final int MAX_STACK = 1024;

	private static volatile int maxStackSize = 64;

	public static int getMaxStackSize() {
		return maxStackSize;
	}

	public static void setMaxStackSize(int value) {
		maxStackSize = Math.max(MIN_STACK, Math.min(MAX_STACK, value));
	}

	private static Path configPath() {
		return FabricLoader.getInstance().getConfigDir().resolve("bigstacks.properties");
	}

	public static void load() {
		Path path = configPath();
		if (!Files.exists(path)) {
			save();
			return;
		}
		try (InputStream in = Files.newInputStream(path)) {
			Properties props = new Properties();
			props.load(in);
			setMaxStackSize(Integer.parseInt(props.getProperty("maxStackSize", "64").trim()));
		} catch (IOException | NumberFormatException e) {
			LOGGER.warn("Konnte Config nicht lesen, nutze 64", e);
			maxStackSize = 64;
		}
	}

	public static void save() {
		Properties props = new Properties();
		props.setProperty("maxStackSize", Integer.toString(maxStackSize));
		try (OutputStream out = Files.newOutputStream(configPath())) {
			props.store(out, "Big Stacks - Items pro Stack (1-" + MAX_STACK + ")");
		} catch (IOException e) {
			LOGGER.error("Konnte Config nicht speichern", e);
		}
	}

	@Override
	public void onInitialize() {
		load();
		LOGGER.info("Big Stacks geladen, Stackgroesse: {}", maxStackSize);
	}
}
